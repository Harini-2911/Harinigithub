TITLE: SMART IOT-ENABLED PRECISION IRRIGATION SYSTEM WITH AI-DRIVEN PREDICTIONS

Project Description:

	This project develops a Smart IoT-enabled system that integrates plant disease detection, fertilizer recommendation, and automated irrigation using AI and sensor data. It uses InceptionNetV3 to classify leaf diseases and provide suitable treatments for better crop health. The system also monitors soil conditions in real time to optimize water usage and supports sustainable precision farming.

Hardware Requirements:

	Processor	        :	Intel processor 2.6.0 GHZ
	RAM	                :	2 GB
	Hard disk	        :	160 GB
	Power Supply	        :	5v Battery
	Sensors 	        :	Temperature Sensor and Soil Moisture Sensor
	Microcontroller	        :	ATMEGA328 Microcontroller
	Communication Device	:	Relay, UART, IOT
	Motor	                :	Water Motor
	Display              	:	LCD Display

Software Requirements:

	IDE	        :	Arduino IDE,VSC,Anaconda Prompt
	Server Side	:	Python, C
	Client Side	:	Tkinter
	OS	        :	Windows 11

How to Run:

DISEASE PREDICTION

Step 1: Install Visual Studio Code Editor with python and jupyter extension
Step 2: Download the Rice Leaf Disease Dataset.
Step 3: Run the juypter notebook code.
Step 4: open ancoda prompt for hosting the site locally on the desktop
step 5: To activate anacoda prompt type conda activate py310 on command prompt
Step 6: Copy the path of the app.py file and change the directory into the copied path
step 7: Then on the terminal type python app.py to run the file
step 8: Then the app.py file will load the website and you can upload the leaf image and you can check the affected disease and recommended fertilizer for the predicted disease
step 9: The predicted disease and recommended fertilizer for the predicted disease will be displayed on the LCD of the hardware kit

IRRIGATION SYSTEM 

step 1: Connect the hardware kit to the power source and connect all the cables in the hardware device 
step 2: connect the hardware kit to the system using UART cable
step 3: Run the code for disease prediction and Irrigation control on Arduino IDE
step 4: Connect the wi-fi of the device in which IOT Cloud is installed to the hardware device
step 5: Based on the sensor readings the water motor will be automatically turned on/off and the alert will be sent to the farmer using IOT Cloud App
step 6: The predicted disease and recommended fertilizer for the predicted disease will be displayed on the LCD of the hardware kit

