#include <LiquidCrystal.h>
#include "DHT.h"

LiquidCrystal lcd(13, 12, 11, 10, 9, 8);

#define DHTPIN A2
#define DHTTYPE DHT11
#define moisturePin A0

DHT dht(DHTPIN, DHTTYPE);
int A,B;
float t;
int h;
int moisture;

// ---------------- SETUP ----------------
void setup()
{
  Serial.begin(9600);
  lcd.begin(16,2);

  lcd.setCursor(0,0);
  lcd.print(" Smart Plant ");
  lcd.setCursor(0,1);
  lcd.print("   Disease IoT");
  delay(2000);
  lcd.clear();

  dht.begin();

  pinMode(2, OUTPUT);   // motor
  pinMode(4, OUTPUT);   // buzzer
  digitalWrite(4, LOW);
}

// ---------------- LOOP ----------------
void loop()
{
  // ---------- SERIAL DISEASE DISPLAY (LINE 0) ----------
  if (Serial.available() > 0)
  {
    char a = Serial.read();
    lcd.setCursor(0,0);

    if (a == 'A') {
      lcd.print("Bact.Leaf Blight ");
      Serial.print('A');
    }
    else if (a == 'B'){
      lcd.print("Brown Spot       ");
      Serial.print('B');
    }
    else if (a == 'C') {
      lcd.print("Healthy          ");
       Serial.print('C');
    }
    else if (a == 'D'){
      lcd.print("Leaf Blast       ");
       Serial.print('D');
    }
    else if (a == 'E') {
      lcd.print("Leaf Blight      ");
       Serial.print('E');
    }
    else if (a == 'F')
    {
      lcd.print("Leaf Scald       ");
       Serial.print('F');
    }
    else if (a == 'G') {
      lcd.print("Leaf Smut        ");
       Serial.print('G');
    }
    else if (a == 'H') {
    lcd.print("Narrow BrownSpot ");
     Serial.print('H');
    }
    digitalWrite(4, HIGH);
    delay(300);
    digitalWrite(4, LOW);
  }

  // ---------- SENSOR PROCESS ----------
  dht_read();
  mois();

// ---------- MOTOR CONTROL ----------
  if ((A==1) && (B==1) )
  {
    digitalWrite(2, LOW);   // motor OFF
  }
  else 
  {
    digitalWrite(2, HIGH);  // motor ON
  }
  delay(500);
}

// ---------------- DHT FUNCTION ----------------
void dht_read()
{
  float t = dht.readTemperature();
  int h = dht.readHumidity();

  if (isnan(t) || isnan(h)) return;

  lcd.setCursor(0,1);
  lcd.print("T");
  Serial.print('T');
  Serial.print(t);
  lcd.print(t,1);
  lcd.print(" ");

  lcd.setCursor(6,1);
  lcd.print("H");
  Serial.print('U');
  Serial.print(h);
  lcd.print(h);
  lcd.print("%");

  lcd.setCursor(11,1);
  if (t > 35)
  {
    lcd.print("TH");
    A = 1;
    
  }
  else
  {
    lcd.print("TL");
    A = 0;
    
  }
}

// ---------------- MOISTURE FUNCTION ----------------
void mois()
{
  int moisture = digitalRead(moisturePin);

  lcd.setCursor(14,1);
  Serial.print('M');
  Serial.print(moisture);
  if (moisture == HIGH)
  {
    lcd.print("ML");
    Serial.print('Z');
    B=1;
    
  }
  else
  {
    lcd.print("MH");
    Serial.print('z');
    B=0;
  
  }

  
  
}
