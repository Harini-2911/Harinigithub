#include <ArduinoIoTCloud.h>
#include <Arduino_ConnectionHandler.h>
#include <ESP8266WiFi.h>

// ----------------- Credentials (already filled by you) -----------------
const char DEVICE_LOGIN_NAME[]  = "f63dfc42-6b30-4fae-a917-86b10a38f6b7";
const char SSID[]               = "Agri_project";
const char PASS[]               = "1234567890";
const char DEVICE_KEY[]         = "hVqQDDw19zA79Zzezl7Xm0qvu";
// ----------------------------------------------------------------------

void onStatusChange();
void onHumiChange();
void onMoistureChange();
void onTempChange();
void onMoistureLevelChange();

String status;
int humi;
int moisture;
float temp;
bool moisture_level;

void initProperties(){

  ArduinoCloud.setBoardId(DEVICE_LOGIN_NAME);
  ArduinoCloud.setSecretDeviceKey(DEVICE_KEY);
  ArduinoCloud.addProperty(status, READWRITE, ON_CHANGE, onStatusChange);
  ArduinoCloud.addProperty(humi, READWRITE, ON_CHANGE, onHumiChange);
  ArduinoCloud.addProperty(moisture, READWRITE, ON_CHANGE, onMoistureChange);
  ArduinoCloud.addProperty(temp, READWRITE, ON_CHANGE, onTempChange);
  ArduinoCloud.addProperty(moisture_level, READWRITE, ON_CHANGE, onMoistureLevelChange);

}

WiFiConnectionHandler ArduinoIoTPreferredConnection(SSID, PASS);

unsigned long lastSend = 0;
const unsigned long sendInterval = 5000;

void setup() {
  Serial.begin(9600);
  delay(1000);
  initProperties();
  ArduinoCloud.begin(ArduinoIoTPreferredConnection);
  setDebugMessageLevel(2);
  ArduinoCloud.printDebugInfo();
  
}

void loop() {
  ArduinoCloud.update(); // Update IoT Cloud

  if (Serial.available() > 0) {
    char identifier = Serial.read();

    switch (identifier) {
      case 'T': 
        temp = Serial.parseFloat(); 
        break;

      case 'U': 
        humi = Serial.parseInt(); 
        break;
      case 'M': 
        moisture = Serial.parseInt(); 
        break;   
      
       case 'Z': 
        moisture_level = true; 
        break;
        case 'z': 
        moisture_level = false; 
        break;        


      case 'A': status = "Bact.Leaf Blight"; break;
      case 'B': status = "Brown Spot"; break;
      case 'C': status = "Healthy"; break;
      case 'D': status = "Leaf Blast"; break;
      case 'E': status = "Leaf Blight"; break;
      case 'F': status = "Leaf Scald"; break;
      case 'G': status = " Leaf Smut"; break;
      case 'H': status = "Narrow BrownSpot"; break;
    }
  }
}


/*
  Since Temp is READ_WRITE variable, onTempChange() is
  executed every time a new value is received from IoT Cloud.
*/
void onTempChange()  {
  // Add your code here to act upon Temp change
}


/*
  Since Moisture is READ_WRITE variable, onMoistureChange() is
  executed every time a new value is received from IoT Cloud.
*/
void onMoistureChange()  {
  // Add your code here to act upon Moisture change
}

/*
  Since Status is READ_WRITE variable, onStatusChange() is
  executed every time a new value is received from IoT Cloud.
*/
void onStatusChange()  {
  // Add your code here to act upon Status change
}

/*
  Since Humi is READ_WRITE variable, onHumiChange() is
  executed every time a new value is received from IoT Cloud.
*/
void onHumiChange()  {
  // Add your code here to act upon Humi change
}

/*
  Since MoistureLevel is READ_WRITE variable, onMoistureLevelChange() is
  executed every time a new value is received from IoT Cloud.
*/
void onMoistureLevelChange()  {
  // Add your code here to act upon MoistureLevel change
}
