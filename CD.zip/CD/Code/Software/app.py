import tkinter as tk
from tkinter import filedialog, ttk
from PIL import Image, ImageTk
import numpy as np
import tensorflow as tf
import cv2
import serial
import time
import sys

# ===============================
# LOAD MODEL
# ===============================
model = tf.keras.models.load_model("model.h5")
IMG_H, IMG_W = 224, 224

# ===============================
# LABELS
# ===============================
class_labels = {
    'A': 'Bacterial Leaf Blight',
    'B': 'Brown Spot',
    'C': 'Healthy',
    'D': 'Leaf Blast',
    'E': 'Leaf Blight',
    'F': 'Leaf Scald',
    'G': 'Leaf Smut',
    'H': 'Narrow Brown Spot'
}

fertilizer_suggestions = {
    'A': 'Use Nitrogen-rich fertilizer like Urea (46% N).',
    'B': 'Apply Potassium-based fertilizers (MOP).',
    'C': 'No fertilizer required. Crop is healthy.',
    'D': 'Use balanced NPK (10-26-26).',
    'E': 'Apply Zinc Sulphate and organic compost.',
    'F': 'Use Phosphorus fertilizer like DAP.',
    'G': 'Apply fungicide and organic compost.',
    'H': 'Use Potash and Phosphorus. Avoid excess irrigation.'
}

# ===============================
# ARDUINO
# ===============================
arduino = None
try:
    arduino = serial.Serial("COM3", 9600, timeout=1)
    time.sleep(2)
    arduino_status = "🟢 Arduino Connected"
except:
    arduino_status = "🔴 Arduino Not Connected"

def send_to_arduino(letter):
    if arduino and arduino.is_open:
        arduino.write(f"{letter}\n".encode())

# ===============================
# PREDICTION
# ===============================
def predict_image(img):
    img_resized = img.resize((IMG_W, IMG_H))
    arr = np.expand_dims(np.array(img_resized) / 255.0, axis=0)
    pred = model.predict(arr, verbose=0)
    idx = np.argmax(pred)
    key = list(class_labels.keys())[idx]
    send_to_arduino(key)
    return key, class_labels[key], fertilizer_suggestions[key]

# ===============================
# DISPLAY
# ===============================
def update_ui(img, code, disease, fertilizer):
    img_disp = img.resize((360, 360))
    img_tk = ImageTk.PhotoImage(img_disp)
    image_box.config(image=img_tk)
    image_box.image = img_tk

    code_var.set(code)
    disease_var.set(disease)
    fert_var.set(fertilizer)

# ===============================
# INPUT
# ===============================
def upload_image():
    path = filedialog.askopenfilename()
    if not path:
        return
    img = Image.open(path).convert("RGB")
    update_ui(img, *predict_image(img))

def capture_camera():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        status_var.set("❌ Webcam Error")
        return

    while True:
        ret, frame = cap.read()
        cv2.imshow("Press SPACE to Capture", frame)
        if cv2.waitKey(1) & 0xFF == 32:
            break

    cap.release()
    cv2.destroyAllWindows()

    img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    update_ui(img, *predict_image(img))

# ===============================
# WINDOW
# ===============================
root = tk.Tk()
root.title("Rice Leaf AI Detection System")
root.geometry("1200x750")
root.minsize(1100, 700)
root.configure(bg="#eef5f1")

style = ttk.Style()
style.theme_use("clam")
style.configure("TButton", font=("Segoe UI", 11), padding=8)

# ===============================
# HEADER
# ===============================
header = tk.Frame(root, bg="#0b3d2e", height=90)
header.pack(fill="x")

tk.Label(
    header,
    text="Rice Leaf Disease Detection System",
    font=("Segoe UI", 24, "bold"),
    bg="#0b3d2e",
    fg="white"
).pack(pady=(15, 0))

tk.Label(
    header,
    text="AI-Based Disease Classification & Fertilizer Recommendation",
    font=("Segoe UI", 12),
    bg="#0b3d2e",
    fg="#c8e6c9"
).pack()

# ===============================
# MAIN BODY
# ===============================
body = tk.Frame(root, bg="#eef5f1")
body.pack(fill="both", expand=True, padx=20, pady=15)

body.columnconfigure(1, weight=1)
body.rowconfigure(0, weight=1)

# ===============================
# LEFT PANEL
# ===============================
left = tk.Frame(body, bg="white", bd=2, relief="groove")
left.grid(row=0, column=0, sticky="ns", padx=(0, 15))

tk.Label(left, text="INPUT PANEL", font=("Segoe UI", 16, "bold"),
         bg="white").pack(pady=20)

ttk.Button(left, text="📂 Upload Leaf Image",
           command=upload_image).pack(pady=12, ipadx=20)

ttk.Button(left, text="📷 Capture from Camera",
           command=capture_camera).pack(pady=12, ipadx=20)

tk.Label(left, text="System Status", font=("Segoe UI", 14, "bold"),
         bg="white").pack(pady=(40, 5))

status_var = tk.StringVar(value=arduino_status)
tk.Label(left, textvariable=status_var,
         bg="white", fg="green").pack(pady=5)

# ===============================
# RIGHT PANEL
# ===============================
right = tk.Frame(body, bg="white", bd=2, relief="groove")
right.grid(row=0, column=1, sticky="nsew")

right.columnconfigure(0, weight=1)

image_box = tk.Label(right, bg="#f5fdf9")
image_box.pack(pady=20)

# ===============================
# RESULT CARD
# ===============================
card = tk.Frame(right, bg="#f1f8f4", bd=1, relief="solid")
card.pack(fill="x", padx=30, pady=10)

card.columnconfigure(1, weight=1)

code_var = tk.StringVar(value="--")
disease_var = tk.StringVar(value="--")
fert_var = tk.StringVar(value="--")

tk.Label(card, text="Disease Code :", font=("Segoe UI", 12, "bold"),
         bg="#f1f8f4").grid(row=0, column=0, sticky="w", padx=15, pady=6)
tk.Label(card, textvariable=code_var,
         bg="#f1f8f4", font=("Segoe UI", 12)).grid(row=0, column=1, sticky="w")

tk.Label(card, text="Disease Name :", font=("Segoe UI", 12, "bold"),
         bg="#f1f8f4").grid(row=1, column=0, sticky="w", padx=15, pady=6)
tk.Label(card, textvariable=disease_var,
         bg="#f1f8f4", font=("Segoe UI", 12)).grid(row=1, column=1, sticky="w")

tk.Label(card, text="Fertilizer Recommendation :", font=("Segoe UI", 12, "bold"),
         bg="#f1f8f4").grid(row=2, column=0, sticky="nw", padx=15, pady=6)

tk.Message(card, textvariable=fert_var, width=550,
           bg="#f1f8f4", font=("Segoe UI", 11),
           justify="left").grid(row=2, column=1, sticky="w", pady=6)

# ===============================
# EXIT
# ===============================
def on_close():
    if arduino and arduino.is_open:
        arduino.close()
    root.destroy()
    sys.exit()

root.protocol("WM_DELETE_WINDOW", on_close)
root.mainloop()
